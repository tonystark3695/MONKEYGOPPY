var back,ground,score;
var Monkey,bananaI,Stone,backI,score,playerA,player;

var bananaG;

function preload(){

  backI = loadImage("Amazon-Rain-Forest.jpg");
 MonkeyA=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
 Stone=loadImage("download12345-removebg-preview.png")

}
function setup() {
  createCanvas(600, 400);
  back=createSprite(300,height/2,600,400);
  back.addImage("back",backI);
  back.x=back.width/2;
  back.velocityX = -3
  console.log(back.width)

  
  Monkey=createSprite(50,371,10,20)
  Monkey.addAnimation("monk",MonkeyA);
  Monkey.scale=0.1
  
} 
    
function draw() {
 background("white");
  if(back.x<0){
    back.x = back.width/2
  }
  drawSprites();
}

function spawnBanana(){


}

  
  function spawnStone(){
    if (frameCount%60===0){
  var Stone=createSprite(400,300,20,10);
  Stone.velocityX=-10;
  Stone.setAnimation("download12345-removebg-preview.png");
  Stone.scale=1;
  Stone.x=randomNumber(371,0);
  
}
}